# Rythim Glass — Android music player

Rythim Glass is an Android Studio project for a local music player with an original dark, translucent “liquid glass” visual style. It is inspired by modern music-player conventions, not an Apple Music clone and does not use Apple's trademarks or assets.

## Included
- Jetpack Compose UI with home, search, library, mini-player, and full-screen player.
- Local audio discovery through Android `MediaStore` after the user grants audio permission.
- Local playback through `MediaPlayer`, including play/pause, previous/next, seeking, shuffle, repeat-current-track, and automatic next-track handling.
- Animated ambient gradients, glass-like cards, and a rotating disc motif while playing.
- Scrollable search and library lists, plus a refresh action that requests audio permission when needed.
- A demo catalogue used only to preview the design when the device has no indexed music. Demo tracks are not playable audio.

## Requirements
- Android Studio stable release
- JDK 17
- Android SDK Platform 35
- Internet access during the first Gradle sync to download dependencies

Minimum Android version: Android 8.0 (API 26).

## Build an APK in Android Studio
1. Extract the ZIP.
2. Open the `RythimGlass` folder in Android Studio.
3. Let Gradle sync and install any SDK components Android Studio requests.
4. Select **Build → Build APK(s)**.
5. If the build succeeds, Android Studio shows a notification with the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Current limitations — read before using
- This is source code, **not a prebuilt or device-tested APK**.
- This version does not include a foreground playback service or media notification, so background playback and lock-screen controls are not guaranteed.
- No online streaming, account system, cloud sync, playlist persistence, or embedded album artwork extraction is included.
- Device audio formats and access vary by Android version and manufacturer.
- The project has not been compiled or tested on a physical device in this environment because Android SDK/Gradle build tools are unavailable here. A successful Android Studio build and device test are still required before calling it release-ready.

## Permissions and privacy
The app requests `READ_MEDIA_AUDIO` on Android 13+ or the legacy `READ_EXTERNAL_STORAGE` permission on older supported versions to list music on the device. It does not need a user account or network permission for local playback.

## Build APK in the cloud (when Android SDK is not installed locally)

This project includes `.github/workflows/build-apk.yml`. To use it:
1. Create a repository on GitHub and upload the extracted contents of this project.
2. Open the repository's **Actions** tab and select **Build Rythim Glass APK**.
3. Press **Run workflow** (or push to the `main`/`master` branch).
4. Wait for the workflow to finish. If it succeeds, open the run and download the `RythimGlass-debug-apk` artifact.
5. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. You may need to allow installation from the app you used to download it.

The workflow is provided as a build route, not proof that the build has already succeeded. The APK must be downloaded from a successful workflow run. Debug APKs are suitable for personal testing, not Play Store release.
