package com.example.rythimglass

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(8, 10, 18)
        setContent { RythimApp() }
    }
}

private val Ink = Color(0xFF080A12)
private val White = Color(0xFFF7F7FB)
private val Muted = Color(0xFFA7A8B8)
private val Pink = Color(0xFFFF5B8A)
private val Violet = Color(0xFF8C7BFF)
private val Cyan = Color(0xFF69DDF2)

private data class Track(val title: String, val artist: String, val colors: List<Color>, val tag: String, val uri: Uri? = null, val durationMs: Long = 0L)
private val demoTracks = listOf(
    Track("Midnight City", "M83", listOf(Color(0xFF392D78), Color(0xFFEC679D)), "M"),
    Track("Ocean Eyes", "Billie Eilish", listOf(Color(0xFF1B5D73), Color(0xFF85D6D5)), "O"),
    Track("Afterglow", "Ed Sheeran", listOf(Color(0xFF8D3D48), Color(0xFFF5B66C)), "A"),
    Track("Golden Hour", "JVKE", listOf(Color(0xFFB66B30), Color(0xFFF5D27A)), "G"),
    Track("The Less I Know The Better", "Tame Impala", listOf(Color(0xFF23645E), Color(0xFFB5D86C)), "T"),
    Track("Sunset Lover", "Petit Biscuit", listOf(Color(0xFF5D4AA8), Color(0xFFF3A6A0)), "S")
)
private var tracks by mutableStateOf(demoTracks)

private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun loadDeviceTracks(context: android.content.Context): List<Track> {
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    val result = mutableListOf<Track>()
    val palette = listOf(
        listOf(Color(0xFF392D78), Color(0xFFEC679D)), listOf(Color(0xFF1B5D73), Color(0xFF85D6D5)),
        listOf(Color(0xFF8D3D48), Color(0xFFF5B66C)), listOf(Color(0xFFB66B30), Color(0xFFF5D27A)),
        listOf(Color(0xFF23645E), Color(0xFFB5D86C)), listOf(Color(0xFF5D4AA8), Color(0xFFF3A6A0))
    )
    context.contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            val uri = Uri.withAppendedPath(collection, id.toString())
            val title = cursor.getString(titleCol) ?: "Unknown track"
            val artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
            val duration = cursor.getLong(durationCol)
            result += Track(title, artist, palette[result.size % palette.size], title.take(1).uppercase(), uri, duration)
        }
    }
    return result
}

@Composable
private fun RythimApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf("Listen Now") }
    var selected by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var liked by remember { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatEnabled by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var showPlayer by remember { mutableStateOf(false) }
    var permissionMessage by remember { mutableStateOf("") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }

    BackHandler(enabled = showPlayer) { showPlayer = false }

    fun startTrack(index: Int) {
        if (tracks.isEmpty()) return
        selected = index.coerceIn(0, tracks.lastIndex)
        val track = tracks[selected]
        player?.release()
        player = null
        positionMs = 0L
        durationMs = track.durationMs
        if (track.uri != null) {
            try {
                player = MediaPlayer().apply {
                    setDataSource(context, track.uri)
                    setOnPreparedListener { mp ->
                        durationMs = mp.duration.coerceAtLeast(0).toLong()
                        mp.start()
                        playing = true
                        permissionMessage = ""
                    }
                    setOnCompletionListener {
                        if (repeatEnabled) {
                            startTrack(selected)
                        } else if (tracks.isNotEmpty()) {
                            if (shuffleEnabled && tracks.size > 1) {
                                startTrack(tracks.indices.filter { it != selected }.random())
                            } else {
                                startTrack((selected + 1) % tracks.size)
                            }
                        }
                    }
                    setOnErrorListener { _, _, _ ->
                        playing = false
                        permissionMessage = "File audio tidak dapat diputar. Coba lagu lain."
                        true
                    }
                    prepareAsync()
                }
                playing = false
                permissionMessage = ""
            } catch (_: Exception) {
                playing = false
                permissionMessage = "Lagu tidak dapat diputar. Coba pilih file audio lain."
            }
        } else {
            playing = false
            permissionMessage = "Pilih lagu dari Library untuk memutar audio di perangkat."
        }
        showPlayer = true
    }

    fun togglePlayback() {
        val mp = player
        if (mp == null) {
            playing = false
            permissionMessage = if (tracks.getOrNull(selected)?.uri == null)
                "Pilih lagu lokal dari Library. Lagu demo hanya contoh tampilan."
            else "Pemutar belum siap. Pilih lagu lagi untuk mencoba."
            return
        }
        try {
            if (mp.isPlaying) {
                mp.pause()
                playing = false
            } else {
                mp.start()
                playing = true
                permissionMessage = ""
            }
        } catch (_: IllegalStateException) {
            playing = false
            permissionMessage = "Pemutar berhenti. Coba pilih lagu kembali."
        }
    }

    fun nextTrack() {
        if (tracks.isEmpty()) return
        if (shuffleEnabled && tracks.size > 1) {
            val candidates = tracks.indices.filter { it != selected }
            startTrack(candidates.random())
        } else {
            startTrack((selected + 1) % tracks.size)
        }
    }

    fun previousTrack() {
        if (tracks.isNotEmpty()) startTrack((selected - 1 + tracks.size) % tracks.size)
    }

    fun loadSongs() {
        try {
            val found = loadDeviceTracks(context)
            if (found.isNotEmpty()) {
                val previousUri = tracks.getOrNull(selected)?.uri
                tracks = found
                selected = found.indexOfFirst { it.uri == previousUri }.takeIf { it >= 0 } ?: 0
                permissionMessage = "${found.size} lagu ditemukan di perangkat"
            } else {
                if (player != null) {
                    try { player?.stop() } catch (_: IllegalStateException) { }
                    player?.release()
                    player = null
                    playing = false
                    positionMs = 0L
                    durationMs = 0L
                }
                tracks = demoTracks
                selected = 0
                permissionMessage = "Belum ada lagu lokal ditemukan. Tambahkan file audio ke HP lalu muat ulang."
            }
        } catch (_: Exception) { permissionMessage = "Tidak dapat membaca koleksi musik perangkat." }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadSongs() else permissionMessage = "Izin audio diperlukan untuk menampilkan lagu di HP."
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else permissionLauncher.launch(audioPermission())
    }
    LaunchedEffect(playing, player) {
        while (true) {
            val mp = player
            if (playing && mp != null) {
                try { positionMs = mp.currentPosition.toLong(); durationMs = mp.duration.toLong() } catch (_: Exception) { }
            }
            delay(350)
        }
    }
    DisposableEffect(Unit) { onDispose { player?.release(); player = null } }

    Box(Modifier.fillMaxSize().background(Ink)) {
        AmbientBackdrop()
        Column(Modifier.fillMaxSize()) {
            AnimatedContent(targetState = tab, label = "page", modifier = Modifier.weight(1f)) { page ->
                when (page) {
                    "Search" -> SearchPage(search, { search = it }, { startTrack(it) })
                    "Library" -> LibraryPage(
                        onPlay = { startTrack(it) },
                        onRefresh = {
                            if (ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED) loadSongs()
                            else permissionLauncher.launch(audioPermission())
                        },
                        message = permissionMessage
                    )
                    else -> HomePage(onPlay = { startTrack(it) }, onOpenPlayer = { showPlayer = true })
                }
            }
            if (!showPlayer) MiniPlayer(track = tracks.getOrElse(selected) { demoTracks.first() }, playing = playing, onToggle = { togglePlayback() }, onNext = { nextTrack() }, onClick = { showPlayer = true })
            BottomBar(tab = tab, onTab = { tab = it; showPlayer = false })
        }
        if (showPlayer) FullPlayer(track = tracks.getOrElse(selected) { demoTracks.first() }, playing = playing, liked = liked,
            shuffle = shuffleEnabled, repeat = repeatEnabled,
            positionMs = positionMs, durationMs = durationMs,
            onBack = { showPlayer = false }, onToggle = { togglePlayback() }, onLike = { liked = !liked },
            onShuffle = { shuffleEnabled = !shuffleEnabled }, onRepeat = { repeatEnabled = !repeatEnabled },
            onSeek = { target -> try { player?.seekTo(target.toInt()); positionMs = target } catch (_: Exception) { } },
            onNext = { nextTrack() }, onPrevious = { previousTrack() })
    }
}

@Composable
private fun AmbientBackdrop() {
    val transition = rememberInfiniteTransition(label = "ambient")
    val drift by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "drift")
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101328), Ink, Color(0xFF080A12)))))
    Box(Modifier.fillMaxWidth().height(390.dp).offset(x = (-90 + drift * 35).dp, y = (-110).dp).background(Brush.radialGradient(listOf(Violet.copy(alpha = .28f), Color.Transparent), radius = 520f)))
    Box(Modifier.fillMaxWidth().height(360.dp).offset(x = (140 - drift * 40).dp, y = 260.dp).background(Brush.radialGradient(listOf(Pink.copy(alpha = .15f), Color.Transparent), radius = 450f)))
}

@Composable
private fun HomePage(onPlay: (Int) -> Unit, onOpenPlayer: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d", Locale.getDefault())).uppercase(Locale.getDefault()), color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.6.sp)
                    Text("Listen Now", color = White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pink, Violet))).border(1.dp, Color.White.copy(.35f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Headphones, null, tint = White, modifier = Modifier.size(22.dp))
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth().height(218.dp), radius = 30.dp) {
                Box(Modifier.fillMaxSize()) {
                    Box(Modifier.align(Alignment.CenterEnd).size(220.dp).offset(x = 45.dp, y = 15.dp).background(Brush.radialGradient(listOf(Pink.copy(.8f), Violet.copy(.45f), Color.Transparent), radius = 350f)))
                    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Pink, modifier = Modifier.size(15.dp))
                            Text("YOUR DAILY MIX", color = White.copy(.8f), fontSize = 11.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("A little more", color = White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                            Text("feeling.", color = White, fontSize = 29.sp, fontWeight = FontWeight.Light)
                            Spacer(Modifier.height(13.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Made for your moment", color = White.copy(.78f), fontSize = 12.sp, modifier = Modifier.weight(1f))
                                IconButton(onClick = { onPlay(0) }, modifier = Modifier.size(45.dp).clip(CircleShape).background(White)) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Ink, modifier = Modifier.size(30.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
        item { SectionHeading("Recently played", "See all") }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                tracks.take(4).forEachIndexed { index, track ->
                    Column(Modifier.width(142.dp).clickable { onPlay(index) }) {
                        AlbumArt(track, Modifier.size(142.dp), 24.dp)
                        Spacer(Modifier.height(10.dp))
                        Text(track.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
        item { SectionHeading("Made for you", "Explore") }
        itemsIndexed(tracks.drop(2)) { index, track ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onPlay(index + 2) }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                AlbumArt(track, Modifier.size(58.dp), 15.dp)
                Column(Modifier.weight(1f).padding(start = 13.dp)) {
                    Text(track.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(track.artist, color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.MoreHoriz, null, tint = Muted)
            }
        }
    }
}

@Composable
private fun SearchPage(query: String, onQuery: (String) -> Unit, onPlay: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 25.dp)) {
        Text("Search", color = White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        var text by remember { mutableStateOf(query) }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(.09f)).border(1.dp, Color.White.copy(.13f), RoundedCornerShape(18.dp)).padding(horizontal = 15.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Muted)
            Spacer(Modifier.width(10.dp))
            androidx.compose.foundation.text.BasicTextField(value = text, onValueChange = { text = it; onQuery(it) }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp), decorationBox = { inner -> if (text.isEmpty()) Text("Artists, songs, albums", color = Muted); inner() })
        }
        Spacer(Modifier.height(22.dp))
        Text(if (text.isBlank()) "TRENDING NOW" else "RESULTS", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        val filtered = tracks.mapIndexed { i, t -> i to t }.filter { text.isBlank() || it.second.title.contains(text, true) || it.second.artist.contains(text, true) }
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            if (filtered.isEmpty()) {
                item {
                    Text(if (text.isBlank()) "Belum ada lagu. Muat koleksi di Library." else "Tidak ada lagu yang cocok.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 24.dp))
                }
            }
            itemsIndexed(filtered) { _, pair ->
                val (index, track) = pair
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onPlay(index) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AlbumArt(track, Modifier.size(58.dp), 15.dp)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(track.title, color = White, fontWeight = FontWeight.SemiBold); Text(track.artist, color = Muted, fontSize = 12.sp) }
                    Icon(Icons.Default.PlayCircle, null, tint = White.copy(.8f), modifier = Modifier.size(27.dp))
                }
            }
        }
    }
}

@Composable
private fun LibraryPage(onPlay: (Int) -> Unit, onRefresh: () -> Unit, message: String) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 25.dp)) {
        Text("Library", color = White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Your music, your mood.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(message.ifBlank { "Lagu di perangkat" }, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = Pink) }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(Icons.Default.PlaylistPlay to "Playlists", Icons.Default.Album to "Albums", Icons.Default.Person to "Artists").forEach { (icon, label) ->
                GlassCard(Modifier.weight(1f).height(88.dp), radius = 20.dp) { Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(icon, null, tint = Pink); Text(label, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) } }
            }
        }
        Spacer(Modifier.height(25.dp))
        Text("RECENTLY ADDED", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            if (tracks.isEmpty()) {
                item { Text("Belum ada lagu di pustaka.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 20.dp)) }
            }
            itemsIndexed(tracks) { index, track ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onPlay(index) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    AlbumArt(track, Modifier.size(56.dp), 14.dp)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(track.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    Icon(Icons.Default.MoreHoriz, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun FullPlayer(track: Track, playing: Boolean, liked: Boolean, shuffle: Boolean, repeat: Boolean, positionMs: Long, durationMs: Long, onBack: () -> Unit, onToggle: () -> Unit, onLike: () -> Unit, onShuffle: () -> Unit, onRepeat: () -> Unit, onSeek: (Long) -> Unit, onNext: () -> Unit, onPrevious: () -> Unit) {
    val scale by animateFloatAsState(if (playing) 1f else .94f, tween(700, easing = FastOutSlowInEasing), label = "coverScale")
    val rotationTransition = rememberInfiniteTransition(label = "albumRotation")
    val rotation by rotationTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(18000, easing = androidx.compose.animation.core.LinearEasing), RepeatMode.Restart),
        label = "albumRotationAngle"
    )
    val albumRotation = if (playing) rotation else 0f
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(track.colors[0].copy(.82f), Color(0xFF111222), Ink)))) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(track.colors[1].copy(.28f), Color.Transparent), radius = 700f)))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.KeyboardArrowDown, null, tint = White, modifier = Modifier.size(32.dp)) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) { Text("NOW PLAYING", color = White.copy(.65f), fontSize = 10.sp, letterSpacing = 2.sp); Text("Playing from your mix", color = White, fontSize = 12.sp) }
                IconButton(onClick = {}) { Icon(Icons.Default.MoreHoriz, null, tint = White) }
            }
            Spacer(Modifier.weight(.7f))
            AlbumArt(track, Modifier.fillMaxWidth().aspectRatio(1f).scale(scale), 30.dp, true, albumRotation)
            Spacer(Modifier.weight(.65f))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = White.copy(.65f), fontSize = 16.sp)
                }
                IconButton(onClick = onLike) { Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (liked) Pink else White, modifier = Modifier.size(27.dp)) }
            }
            Spacer(Modifier.height(23.dp))
            val safeDuration = durationMs.coerceAtLeast(1L)
            Slider(value = (positionMs.toFloat() / safeDuration).coerceIn(0f, 1f), onValueChange = { onSeek((it * safeDuration).toLong()) }, colors = SliderDefaults.colors(thumbColor = White, activeTrackColor = White, inactiveTrackColor = White.copy(.22f)), modifier = Modifier.height(25.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(positionMs), color = Muted, fontSize = 11.sp); Text(formatTime(durationMs), color = Muted, fontSize = 11.sp) }
            Spacer(Modifier.height(15.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Cyan else Muted, modifier = Modifier.size(22.dp)) }
                IconButton(onClick = onPrevious, modifier = Modifier.size(50.dp)) { Icon(Icons.Default.SkipPrevious, null, tint = White, modifier = Modifier.size(36.dp)) }
                IconButton(onClick = onToggle, modifier = Modifier.size(70.dp).clip(CircleShape).background(White)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Ink, modifier = Modifier.size(39.dp)) }
                IconButton(onClick = onNext, modifier = Modifier.size(50.dp)) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(36.dp)) }
                IconButton(onClick = onRepeat) { Icon(Icons.Default.Repeat, null, tint = if (repeat) Cyan else Muted, modifier = Modifier.size(22.dp)) }
            }
            Spacer(Modifier.height(20.dp))
            GlassCard(Modifier.fillMaxWidth().height(48.dp), radius = 16.dp) { Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Speaker, null, tint = Cyan, modifier = Modifier.size(18.dp)); Text("  Listening on this device", color = White.copy(.8f), fontSize = 12.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Default.QueueMusic, null, tint = Muted) } }
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
private fun MiniPlayer(track: Track, playing: Boolean, onToggle: () -> Unit, onNext: () -> Unit, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(66.dp), radius = 20.dp) {
        Row(Modifier.fillMaxSize().clickable { onClick() }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(track, Modifier.size(44.dp), 12.dp)
            Column(Modifier.weight(1f).padding(start = 11.dp)) { Text(track.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1); Text(track.artist, color = Muted, fontSize = 11.sp) }
            IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(26.dp)) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(25.dp)) }
        }
    }
}

@Composable
private fun BottomBar(tab: String, onTab: (String) -> Unit) {
    GlassCard(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 9.dp, bottom = 7.dp).height(67.dp), radius = 24.dp) {
        Row(Modifier.fillMaxSize().padding(horizontal = 7.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            listOf(Triple("Listen Now", Icons.Default.Headphones, "Listen Now"), Triple("Search", Icons.Default.Search, "Search"), Triple("Library", Icons.Default.LibraryMusic, "Library")).forEach { (label, icon, text) ->
                val active = tab == label
                Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp)).clickable { onTab(label) }.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(icon, null, tint = if (active) Pink else Muted, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.height(3.dp))
                    Text(text, color = if (active) White else Muted, fontSize = 10.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun AlbumArt(track: Track, modifier: Modifier = Modifier, radius: androidx.compose.ui.unit.Dp = 20.dp, hero: Boolean = false, rotation: Float = 0f) {
    Box(modifier.clip(RoundedCornerShape(radius)).background(Brush.linearGradient(track.colors)).border(1.dp, Color.White.copy(.23f), RoundedCornerShape(radius))) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color.White.copy(.30f), Color.Transparent), radius = 320f)))
        Box(Modifier.align(Alignment.Center).fillMaxSize(.73f).rotate(rotation).clip(CircleShape).border(if (hero) 2.dp else 1.dp, Color.White.copy(.35f), CircleShape).background(Brush.radialGradient(listOf(track.colors[1].copy(.75f), track.colors[0].copy(.8f), Color.Transparent))))
        Box(Modifier.align(Alignment.Center).size(if (hero) 100.dp else 34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color.White.copy(.35f), Color.White.copy(.03f)))).border(1.dp, Color.White.copy(.35f), CircleShape), contentAlignment = Alignment.Center) {
            Text(track.tag, color = White.copy(.92f), fontSize = if (hero) 62.sp else 22.sp, fontWeight = FontWeight.Light)
        }
        Box(Modifier.fillMaxWidth().height(35.dp).align(Alignment.BottomCenter).background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.25f)))))
    }
}

@Composable
private fun SectionHeading(title: String, action: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = Pink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, radius: androidx.compose.ui.unit.Dp = 24.dp, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(radius)).background(Brush.linearGradient(listOf(Color.White.copy(.13f), Color.White.copy(.055f), Color.White.copy(.075f)))).border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.32f), Color.White.copy(.08f), Color.White.copy(.18f))), RoundedCornerShape(radius)), content = content)
}

private fun formatTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0L) / 1000L).toInt()
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
